/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_H_INCLUDED
# define YY_YY_PARSER_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    DIGIT = 258,
    LETTER = 259,
    TRUE = 260,
    FALSE = 261,
    OPEN_TAG = 262,
    CLOSE_TAG = 263,
    SLASH = 264,
    ELEMENT = 265,
    WHITESPACE = 266,
    NUM_TYPE = 267,
    DATETIME_TYPE = 268,
    BOOLEAN_TYPE = 269,
    STRING_TYPE = 270,
    MINUS = 271,
    PLUS = 272,
    COLON = 273,
    PUNCTUATION = 274,
    COMMENT = 275,
    WORKBOOK = 276,
    WORKSHEET = 277,
    STYLES = 278,
    STYLE = 279,
    ID = 280,
    TABLE = 281,
    NAME = 282,
    PROTECTED = 283,
    COLUMN = 284,
    ROW = 285,
    EXP_COL_CNT = 286,
    EXP_ROW_CNT = 287,
    STYLE_ID = 288,
    HIDDEN = 289,
    WIDTH = 290,
    CELL = 291,
    HEIGHT = 292,
    DATA = 293,
    MERGEACROSS = 294,
    MERGEDOWN = 295,
    TYPE = 296,
    EQUAL = 297,
    QUOTE = 298
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


extern YYSTYPE yylval;
extern YYLTYPE yylloc;
int yyparse (void);

#endif /* !YY_YY_PARSER_TAB_H_INCLUDED  */
